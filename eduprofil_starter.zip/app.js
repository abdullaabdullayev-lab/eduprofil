(() => {
  const form = document.getElementById('login-form');
  const message = document.getElementById('message');
  const button = document.getElementById('login-btn');
  const config = window.EDUPROFIL_CONFIG || {};
  const configured = config.supabaseUrl && config.supabaseAnonKey &&
    !config.supabaseUrl.includes('YOUR-PROJECT') &&
    !config.supabaseAnonKey.includes('YOUR-PUBLISHABLE');

  const say = (text, kind='') => {
    message.textContent = text;
    message.className = `message ${kind}`;
  };

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!configured || !window.supabase?.createClient) {
      say('Supabase hələ qoşulmayıb. Əvvəl config.js faylında layihə URL-i və publishable/anon açarını əlavə edin.', 'error');
      return;
    }
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    button.disabled = true;
    say('Yoxlanılır…');
    try {
      const client = window.supabase.createClient(config.supabaseUrl, config.supabaseAnonKey);
      const { data, error } = await client.auth.signInWithPassword({ email, password });
      if (error) throw error;
      // Giriş uğurlu olsa da, profil məlumatları yalnız RLS ilə qorunan cədvəllərdən oxunmalıdır.
      // Bu starterda şəxsi profil ekranı qəsdən qoşulmayıb; real şema və icazələr test edilməlidir.
      say('Giriş uğurludur. Növbəti mərhələdə icazələrə uyğun profil ekranı qoşulacaq.', 'success');
    } catch (err) {
      say('Giriş alınmadı. Məlumatları yoxlayın və ya müəssisənin məsul şəxsi ilə əlaqə saxlayın.', 'error');
    } finally {
      button.disabled = false;
    }
  });
})();