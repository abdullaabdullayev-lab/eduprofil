// Supabase layihənizin Project URL və publishable/anon açarını buraya yazın.
// Bu fayla service_role/secret key yazmaq QƏTİ QADAĞANDIR.
window.EDUPROFIL_CONFIG = {
  supabaseUrl: "https://YOUR-PROJECT.supabase.co",
  supabaseAnonKey: "YOUR-PUBLISHABLE-OR-ANON-KEY"
};
